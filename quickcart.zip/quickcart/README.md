# ⚡ QuickCart

A responsive product listing page built with **React + Vite** as part of a frontend assignment.

## 🗂 Project Structure

```
quickcart/
├── index.html
├── vite.config.js
├── package.json
└── src/
    ├── main.jsx              # App entry point
    ├── App.jsx               # Root component
    ├── components/
    │   ├── Header.jsx        # Sticky navigation header
    │   ├── ProductList.jsx   # Grid container for products
    │   └── ProductCard.jsx   # Individual product card
    ├── data/
    │   └── products.js       # Static product data (exported)
    └── styles/
        ├── index.css         # Global styles & CSS variables
        ├── App.css           # Hero section & layout
        ├── Header.css        # Header styles
        ├── ProductList.css   # Grid layout
        └── ProductCard.css   # Card styles & hover effects
```

## 🚀 Getting Started

```bash
# 1. Install dependencies
npm install

# 2. Run development server
npm run dev

# 3. Build for production
npm run build
```

## 🔀 Git Workflow (Assignment Submission)

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/quickcart.git
cd quickcart

# Create a feature branch
git checkout -b feature/product-listing

# Stage and commit all files
git add .
git commit -m "feat: initial QuickCart product listing page"

# Push branch to GitHub
git push origin feature/product-listing

# Then open a Pull Request on GitHub from feature/product-listing → main
```

## ✅ Assignment Checklist

- [x] React project set up with Vite
- [x] Folder structure: `components/`, `data/`, `styles/`
- [x] Static product data in `src/data/products.js`
- [x] Reusable components: `Header`, `ProductList`, `ProductCard`
- [x] Dynamic rendering with `.map()` and unique `key` props
- [x] Props used to pass data between components
- [x] Product details: image, name, description, price, category
- [x] Responsive CSS grid layout (4 → 3 → 2 → 1 columns)
- [x] No console errors

## 🛠 Tech Stack

- React 18
- Vite 5
- Plain CSS (no frameworks)
