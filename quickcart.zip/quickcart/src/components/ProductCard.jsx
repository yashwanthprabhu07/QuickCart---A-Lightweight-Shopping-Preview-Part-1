import "../styles/ProductCard.css";

function ProductCard({ product }) {
  const { name, description, price, category, image } = product;

  const formattedPrice = new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(price);

  return (
    <article className="product-card">
      <div className="product-image-wrapper">
        <img
          src={image}
          alt={name}
          className="product-image"
          loading="lazy"
        />
        <span className="product-category">{category}</span>
      </div>
      <div className="product-body">
        <h3 className="product-name">{name}</h3>
        <p className="product-description">{description}</p>
        <div className="product-footer">
          <span className="product-price">{formattedPrice}</span>
          <button className="add-to-cart-btn">
            Add to Cart
          </button>
        </div>
      </div>
    </article>
  );
}

export default ProductCard;
