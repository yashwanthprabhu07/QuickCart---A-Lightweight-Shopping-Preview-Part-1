import "../styles/Header.css";

function Header() {
  return (
    <header className="header">
      <div className="header-inner">
        <div className="header-brand">
          <span className="header-logo">⚡</span>
          <span className="header-title">QuickCart</span>
        </div>
        <nav className="header-nav">
          <a href="#" className="nav-link active">Shop</a>
          <a href="#" className="nav-link">Deals</a>
          <a href="#" className="nav-link">About</a>
        </nav>
        <div className="header-actions">
          <button className="icon-btn" aria-label="Search">
            <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
            </svg>
          </button>
          <button className="icon-btn cart-btn" aria-label="Cart">
            <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/>
            </svg>
            <span className="cart-badge">0</span>
          </button>
        </div>
      </div>
    </header>
  );
}

export default Header;
