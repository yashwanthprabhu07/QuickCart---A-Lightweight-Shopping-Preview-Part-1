import ProductCard from "./ProductCard";
import "../styles/ProductList.css";

function ProductList({ products }) {
  return (
    <section className="product-list-section">
      <div className="product-list-header">
        <h2 className="product-list-title">All Products</h2>
        <span className="product-count">{products.length} items</span>
      </div>
      <div className="product-grid">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </section>
  );
}

export default ProductList;
