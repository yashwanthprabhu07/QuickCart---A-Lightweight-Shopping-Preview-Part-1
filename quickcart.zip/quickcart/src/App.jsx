import Header from "./components/Header";
import ProductList from "./components/ProductList";
import products from "./data/products";
import "./styles/App.css";

function App() {
  return (
    <div className="app">
      <Header />
      <main className="main-content">
        <div className="hero">
          <p className="hero-tag">New Arrivals ✦ Free Shipping over ₹999</p>
          <h1 className="hero-heading">
            Shop Smarter,<br />
            <span className="hero-accent">Checkout Faster.</span>
          </h1>
          <p className="hero-sub">
            Curated products, unbeatable prices — all in one place.
          </p>
        </div>
        <div className="container">
          <ProductList products={products} />
        </div>
      </main>
      <footer className="footer">
        <p>© 2025 QuickCart. Built with React + Vite.</p>
      </footer>
    </div>
  );
}

export default App;
